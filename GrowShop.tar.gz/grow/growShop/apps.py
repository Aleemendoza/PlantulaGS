from django.apps import AppConfig


class GrowshopConfig(AppConfig):
    name = 'growShop'
